<?php
//    $conn=mysqli_connect("localhost:3306","wwwaffordablemed_bestlocalautoinsurance","nextGen2022","wwwaffordablemed_bestlocalautoinsurance") ;
//    if (!$conn){
//     echo "Error Connecting With Database";
// }

$conn = mysqli_connect("localhost", "root", "", "bestlocalauto");
if (!$conn){
    echo "Error Connecting With Database";
}
?>